package com.example.sprint1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button signupButton, loginButton, soundTemp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signupButton = findViewById(R.id.gotosignupButton);
        loginButton = findViewById(R.id.gotologinButton);
        soundTemp = findViewById(R.id.button3);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GotoSignUpPage();
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GotoLoginPage();
            }
        });

        soundTemp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                soundDialogFragment dialog = new soundDialogFragment();
                dialog.show(getSupportFragmentManager(), "MyFragment");
            }

        });
    }

    public void GotoSignUpPage(){
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }
    public void GotoLoginPage(){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }
}